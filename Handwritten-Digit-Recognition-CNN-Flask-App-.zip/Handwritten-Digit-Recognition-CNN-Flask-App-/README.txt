echo "# pragadeesh-mn-mini-porject" >> README.md
git init
git add A
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/Pragadeeshmn/pragadeesh-mn-mini-porject.git
git push -u origin main